# Funnel Master Guide

## Funnel Architecture 1: The Lead Magnet Funnel
- Traffic → Lead Magnet (free) → Email Sequence → Tripwire ($27-47) → Core Offer ($197-497)
- Best for: Cold traffic, content marketers

## Funnel Architecture 2: The Webinar Funnel
- Traffic → Registration → Webinar → Flash Sale → Upsell
- Best for: High-ticket, relationship-based sales

## Funnel Architecture 3: The Application Funnel
- Traffic → Application Form → Qualification Call → Proposal → Close
- Best for: Service businesses, high-ticket coaching

## Copy Templates for Each Stage
- Hook: "Stop [pain point] without [common objection]"
- Bridge: "I tried [alternative] for [time period] but [result]"
- Offer: "Here's exactly what I'd do if I were starting over"
- Close: "This is for you if [qualification criteria]"
