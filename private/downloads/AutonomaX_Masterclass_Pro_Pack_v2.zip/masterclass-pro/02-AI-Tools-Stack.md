# AI Tools Stack — $0-$76/mo Setup

## Free Tier ($0/mo)
1. Groq — Fast open-source LLM inference
2. Gemini — Google's free AI (with API credits)
3. DeepSeek — Cheap inference ($0.14/M tokens)
4. Canva — Design assets (free tier)
5. Make.com — Automation (free 1000 ops/mo)
6. Notion — Knowledge management

## Starter Stack ($19-38/mo)
7. ChatGPT Plus ($20/mo) — Daily content + strategy
8. Claude Pro ($20/mo) — Long-form writing + analysis
9. Midjourney ($10/mo basic) — Visual assets

## Growth Stack ($76/mo)
10. All above + HeyGen ($24/mo) — Video avatars
11. Descript ($24/mo) — Video editing + transcription
12. Zapier ($20/mo) — Advanced integrations

## Exact Prompts
### Content Generator Prompt
```
You are a [role] creating content for [audience].
Write a [type] about [topic].
Tone: [conversational/professional/urgent]
Length: [X words]
Include: [specific elements]
CTA: [desired action]
```

### Sales Copy Prompt
```
Write a sales page for [product] targeting [audience].
The main objection is [objection].
The main desire is [desire].
Price: $[X]
Guarantee: [Y]
Structure: Hook → Problem → Solution → Offer → Close
```
