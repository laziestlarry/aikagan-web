# Traffic Playbook — 7 Channels

## Organic Channels (free)

### 1. LinkedIn
- Post frequency: 5x/week
- Best content: Case studies, frameworks, personal stories
- Formula: Hook (2 lines) → Insight (3-5 lines) → CTA (1 line)
- DM outreach: 10 personalized messages/day

### 2. X.com (Twitter)
- Post frequency: 3-5x/day
- Best content: Threads, hot takes, quick tips
- Growth tactic: Reply to people with 5K+ followers in your niche

### 3. YouTube
- Post frequency: 1x/week
- Best content: Tutorials, case studies, "how I [result]"
- SEO: Target "how to [outcome]" and "[problem] solution" keywords

### 4. Reddit
- Post frequency: 2-3x/week in relevant subreddits
- Best approach: Provide value without promoting
- Subtle CTA: "I wrote about this here" → your content

### 5. Medium
- Post frequency: 1-2x/week
- Best content: Long-form educational posts
- Strategy: Repurpose Twitter threads into Medium articles

## Paid Channels ($)
### 6. LinkedIn Ads
- Best for: B2B, high-ticket offers
- Minimum budget: $10/day
- Targeting: Job title + industry + company size

### 7. Meta Ads (FB/IG)
- Best for: B2C, low-ticket, visual offers
- Minimum budget: $5/day
- Targeting: Interest-based + lookalike audiences
