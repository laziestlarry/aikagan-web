# White-Label Guide — License & Resell

## What You Can License
- AutonomaX Masterclass content (yours to rebrand)
- Funnel templates (customize with your brand)
- Bot scripts (adapt for your clients)
- SOPs and workflows (use in your agency)

## How to Package
1. **Basic License ($497)**: Content rebranding rights
2. **Agency License ($997)**: Content + templates + bots
3. **Enterprise License ($2,497)**: Full system + support

## Rebranding Checklist
- [ ] Change logo and brand colors
- [ ] Update all URLs to your domain
- [ ] Customize examples for your niche
- [ ] Record your own video intros
- [ ] Set your own pricing (recommended 2-3x cost)

## Revenue Splits
- You keep 100% of what you charge
- No royalties or ongoing fees
- Just attribution to original source
