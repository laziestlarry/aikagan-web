# Objection Crusher Scripts

## Script 1: "I don't have time"
"Most people who say this spend 10+ hours a week on things that don't move the needle. This system takes 20 min/day. Can you invest 20 min to change your income?"

## Script 2: "I need to think about it"
"Absolutely. Here's what I'd think about: (1) How long have you been thinking about making a change? (2) What would it cost you to wait another month? (3) What's the first step if you decide yes?"

## Script 3: "It's too expensive"
"I understand. Let me ask — what would it cost you to NOT have this solved? Most people spend more on coffee each month than this investment. And if you don't get results, I'll refund every dollar."

## Script 4: "I can do it myself"
"You probably can. The question is how long it will take you to figure out what's already been figured out here. This isn't information — it's a shortcut. Would you rather build it from scratch or stand on a foundation?"

## Script 5: "Not right now"
"When is 'right now'? Next week? Next month? Most people wait for the 'perfect time' that never comes. What if you started today, even with just the first step?"

## Script 6: "I need to check with my partner"
"Of course. Here's what I'd share with them: the investment, what it includes, and the guarantee. If they have questions, I'm happy to hop on a quick call with both of you."
