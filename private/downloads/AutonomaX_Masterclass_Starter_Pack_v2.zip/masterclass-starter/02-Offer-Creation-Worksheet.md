# Offer Creation Worksheet

## Section 1: Problem Identification
- What specific pain does your customer feel?
- How much is this pain costing them (time/money)?
- What have they tried that didn't work?

## Section 2: Solution Architecture
- Your unique mechanism
- Delivery format (PDF, video, cohort, etc.)
- Timeline to result

## Section 3: Value Metrics
- Tangible outcome (save X hours, make Y dollars)
- Intangible outcome (peace of mind, status, confidence)
- Comparison to alternatives

## Section 4: Offer Construction
- Core deliverable
- Bonuses (overweight, undercost)
- Guarantee structure

## Section 5: Pricing
- Cost-plus vs value-based
- Anchor pricing
- Payment options
