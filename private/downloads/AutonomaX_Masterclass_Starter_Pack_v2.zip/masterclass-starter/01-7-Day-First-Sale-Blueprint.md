# 7-Day First Sale Blueprint

## Day 1: Pick Your Offer
- Choose one problem you can solve
- Use the Offer Creation Worksheet (section 1)

## Day 2: Build Your One-Pager
- Simple landing page with one CTA
- Focus on the transformation, not features

## Day 3: Warm Outreach
- Message 10 people in your network
- Use the Objection Crusher Scripts

## Day 4: Social Proof
- Share your journey, not just the offer
- One post per platform (IG, X, LinkedIn)

## Day 5: Follow Up
- Re-engage everyone who showed interest
- Address objections directly

## Day 6: Close
- Send the payment link
- Offer a time-sensitive bonus

## Day 7: Deliver & Improve
- Over-deliver on your first customer
- Document what worked
