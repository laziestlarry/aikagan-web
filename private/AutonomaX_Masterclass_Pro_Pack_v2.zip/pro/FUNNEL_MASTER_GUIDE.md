# 🏗️ Funnel Master Guide
### 3 Complete Funnel Architectures — Pick One, Build It, Run It

---

## How to Choose Your Funnel

Answer these two questions:

1. **Do I have a digital product (PDF, template, checklist, video)?** → Use Funnel A or B
2. **Am I selling a service (setup, audit, implementation, coaching)?** → Use Funnel C
3. **Do I want to combine both?** → Use Funnel B (hybrid)

---

## FUNNEL A: The Digital Product Ladder
*Best for: fast deployment, passive income, scalable delivery*

### Architecture

```
[TRAFFIC SOURCE] 
     ↓
[LANDING PAGE — Free Lead Magnet]
"Get the [free checklist/template] that [result]"
     ↓
[EMAIL OPT-IN]
     ↓
[THANK YOU PAGE — Tripwire Offer $29]
"Wait — before you download: [Offer Name] for $29"
     ↓
[EMAIL SEQUENCE — 5 days]
Day 1: Deliver free magnet + introduce the $29 offer
Day 2: Case study / proof
Day 3: "Here's what's inside" breakdown
Day 4: Objection handling
Day 5: Last chance + upsell to $79
     ↓
[UPSELL PAGE — $79 Pro Pack]
"Upgrade to the full automation blueprint"
     ↓
[DELIVERY + ONBOARDING EMAIL]
```

### What You Need to Build

| Component | Tool | Time |
|---|---|---|
| Landing page | Carrd.co / Notion / Typedream | 2 hours |
| Email opt-in | MailerLite / Beehiiv (free) | 30 min |
| Tripwire checkout | Gumroad / Lemon Squeezy | 30 min |
| 5-email sequence | Written from templates below | 2–3 hours |
| Upsell page | Duplicate of landing page | 1 hour |

**Total setup time: 6–8 hours**

---

### Funnel A: Landing Page Copy Template

```
HEADLINE:
"Finally: [Specific Result] for [Target Buyer] — Without [Main Pain]"

SUBHEADLINE:
"The [free resource type] used by [social proof number or type of person] to [result]."

BODY (3 bullets):
✓ [Specific thing they'll be able to do after]
✓ [Specific pain this removes]
✓ [Specific outcome in a timeframe]

CTA BUTTON:
"Get Free Access →"

BELOW THE FOLD — Social Proof Block:
"[Name], [title/role]: '[One sentence testimonial or outcome]'"

URGENCY ELEMENT (optional but effective):
"This [checklist / template / guide] is being updated in [X days]. 
Grab the current version free."
```

---

## FUNNEL B: The Audit-to-System Funnel (Hybrid)
*Best for: service + product combination, higher-value conversion*

### Architecture

```
[TRAFFIC — Problem-Aware Content]
Post/DM/Comment: "Are you struggling with [PROBLEM]?"
     ↓
[FREE MICRO-OFFER — $0 or $9]
"Get a 5-point audit of your [system/funnel/process]"
     ↓
[DELIVERY: PDF or Loom audit within 24 hours]
     ↓
[FOLLOW-UP MESSAGE — 24 hours after delivery]
"Based on your audit, here's what I'd recommend doing first.
I've put together the full implementation blueprint: [LINK] — $79"
     ↓
[CHECKOUT — $79 Pro Pack]
     ↓
[DELIVERY + UPSELL EMAIL — Commander $149]
"Ready to go further? The Commander Edition includes [X, Y, Z]"
```

### Why This Funnel Converts

- The free/cheap audit creates **massive perceived value** before they buy
- The personalized follow-up feels like a recommendation, not a pitch
- The natural continuation to the Pro Pack feels logical, not salesy

### Audit Delivery Template

```
Subject: Your [TOPIC] Audit — [First Name]

Hi [Name],

Here's your [5-point / 3-point] audit based on what you shared:

1. [OBSERVATION] → [RECOMMENDATION]
2. [OBSERVATION] → [RECOMMENDATION]
3. [OBSERVATION] → [RECOMMENDATION]
4. [OBSERVATION] → [RECOMMENDATION]
5. [OBSERVATION] → [RECOMMENDATION]

The #1 priority for you: [MOST IMPORTANT POINT]

If you want to implement all of this without building it from scratch,
I put the complete blueprint together: [LINK] — $79.

Questions? Just reply.

[NAME]
```

---

## FUNNEL C: The Service Funnel
*Best for: high-ticket service businesses, implementation work*

### Architecture

```
[TRAFFIC — Authority Content]
Post, comment, or video demonstrating expertise
     ↓
[DM SEQUENCE — 3 messages]
Message 1: Value-first message (share insight, ask question)
Message 2: Introduce the audit/call offer
Message 3: Send booking link
     ↓
[DISCOVERY CALL — 30 min]
     ↓
[PROPOSAL + CLOSE — $149–$997]
     ↓
[ONBOARDING + DELIVERY]
     ↓
[RETENTION / CONTINUATION OFFER]
```

### Service Funnel DM Sequence

**Message 1 (Day 0 — after they engage with your content):**
```
Hey [Name] — your comment on [POST/TOPIC] caught my attention.
[RELEVANT OBSERVATION ABOUT THEIR SITUATION].

Quick question: [SPECIFIC QUESTION ABOUT THEIR PROBLEM]?
```

**Message 2 (Day 1 — after they respond):**
```
That makes sense. A lot of [TYPE OF PERSON] run into that because [REAL REASON].

I've been working on this specifically — I do a 30-min [AUDIT/REVIEW/STRATEGY SESSION] 
where I [SPECIFIC THING YOU COVER].

Would that be useful? No pitch — just an actual look at your situation.
```

**Message 3 (Day 1-2 — after interest confirmed):**
```
Great. Here's a link to book: [CALENDLY/TIDYCAL LINK]

30 minutes. By the end, you'll have [SPECIFIC OUTCOME].
```

---

## Funnel Performance Benchmarks

Use these to know if your funnel is working:

| Metric | Weak | Average | Strong |
|---|---|---|---|
| Landing page opt-in rate | <10% | 15–25% | 30%+ |
| Tripwire conversion rate | <1% | 2–5% | 8%+ |
| Email open rate | <15% | 25–35% | 45%+ |
| Email → sale conversion | <0.5% | 1–3% | 5%+ |
| DM → call booking rate | <5% | 10–20% | 30%+ |
| Call → close rate | <20% | 40–60% | 70%+ |

Track your numbers weekly in the live system.

---

🔗 **https://autonomax-revenue-ops-71658389068.us-central1.run.app**

*AutonomaX Golden Delivery | Pro Edition*
