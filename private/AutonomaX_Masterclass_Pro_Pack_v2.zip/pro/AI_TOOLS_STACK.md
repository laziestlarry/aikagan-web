# 🤖 AI Tools Stack
### Which Tools to Use, How, and In What Order

This is not a comprehensive list of every AI tool. It's the specific stack that runs an AutonomaX-level revenue system efficiently, without overlap or confusion.

---

## The Stack Overview

```
CONTENT + COPY     → Claude / ChatGPT
RESEARCH           → Perplexity AI
LANDING PAGES      → Carrd + AI copy from Claude
EMAIL AUTOMATION   → MailerLite / Beehiiv
OUTREACH WRITING   → Claude / ChatGPT
VISUAL ASSETS      → Canva AI / Adobe Express
VIDEO SHORTS       → CapCut AI / Opus Clip
ANALYTICS          → AutonomaX System + Google Analytics
PAYMENT + DELIVERY → Gumroad / Lemon Squeezy
SCHEDULING         → TidyCal / Calendly
```

---

## Tool-by-Tool Breakdown

### 1. Claude / ChatGPT — Your Copy Engine
**Free tier sufficient for:** Most tasks at this level  
**Use for:**
- Writing all outreach messages
- Drafting landing page copy
- Creating offer descriptions
- Writing email sequences
- Generating social post variations
- Rewriting content in your voice

**The single most important prompt pattern:**
```
"I'm selling [OFFER] to [AUDIENCE] at [$PRICE]. 
The main result is [RESULT]. The main pain it removes is [PAIN].
Write [CONTENT TYPE] that is [TONE] and ends with a clear CTA to [ACTION].
Length: [X words/bullets]."
```

Save this prompt as a template. Fill in the brackets each time.

---

### 2. Perplexity AI — Your Research Engine
**Free tier sufficient for:** Most research  
**Use for:**
- Researching your target niche (what are they asking?)
- Finding communities where your buyers hang out
- Identifying competitors and their pricing
- Finding exact language your audience uses (for copy)

**Best prompt for audience research:**
```
"What are the most common frustrations and questions from 
[YOUR TARGET BUYER TYPE] about [YOUR TOPIC] in 2024-2025?
Show me actual phrases and language they use."
```

Use the phrases in your copy verbatim — buyers respond to their own language.

---

### 3. MailerLite (Free Up to 1,000 Subscribers) — Your Email System
**Setup time:** 45 minutes  
**What to build first:**
1. Welcome sequence (3 emails, automated on sign-up)
2. Nurture sequence (5 emails, 1 every 2 days)
3. Offer email (standalone send, triggered manually or by tag)

**Email #1 — Welcome Template:**
```
Subject: Here's your [LEAD MAGNET] + one thing to do first

Hi [First Name],

Your [resource] is attached / linked here: [LINK]

Before you dive in — the single most important thing in it is [KEY INSIGHT].

Most people skip it. The ones who don't [RESULT].

I'll send you [WHAT'S COMING] over the next few days.

[NAME]
```

---

### 4. Carrd.co — Your Landing Page Builder
**Free tier:** 1 site  
**Paid ($19/year):** Multiple sites, custom domain  
**Build time:** 2–3 hours

**Landing Page Structure (in order):**
1. Hero section: Headline + sub + CTA button
2. Problem section: "If you're [situation], you know how [pain] feels..."
3. Solution section: "That's exactly why I built [OFFER]..."
4. What's inside: 3–5 bullet points (specific deliverables)
5. Social proof: 1–3 quotes (or "early access" framing if none yet)
6. FAQ: 3–4 Q&As (handle the top objections)
7. Final CTA: "Get [OFFER] Now — $[PRICE]"

---

### 5. Gumroad — Your Payment + Delivery Engine
**Cost:** Free (8.5% fee) or $10/month (flat fee)  
**Setup time:** 30 minutes  
**What to upload:** Your product file or link  
**Auto-delivers:** Yes — customer gets download link immediately on purchase

**Pro tip:** Use Gumroad's "Thank You" page redirect to send customers to an onboarding page or upsell offer.

---

### 6. Canva AI — Your Visual Asset Creator
**Free tier sufficient for:** Most visual needs  
**Use for:**
- Social media post graphics (quote cards, carousels, short-form thumbnails)
- Landing page hero images
- PDF formatting (for delivered products)
- YouTube / video thumbnails

**Time-saving AI feature:** "Magic Write" and "AI Image" inside Canva generate professional visuals in minutes.

---

### 7. Opus Clip / CapCut AI — Your Video Content Engine
**Use if:** You're creating short-form video content (Reels, TikTok, YouTube Shorts)  
**What it does:** Takes longer videos and auto-clips into short-form highlights  
**Why it matters:** Short-form video is the highest-reach organic traffic source right now

---

## The Tool Activation Sequence

Don't set up everything at once. Follow this order:

```
Week 1: Claude + Gumroad + Carrd (your sell system)
Week 2: MailerLite (your follow-up system)
Week 3: Perplexity (your research system)
Week 4: Canva + Opus Clip (your content system — only when selling consistently)
```

Each tool serves a specific phase. Adding them in order prevents overwhelm and ensures each one is actually being used before you add the next.

---

## Monthly Tool Cost (At Full Stack)

| Tool | Free Tier | Paid Tier |
|---|---|---|
| Claude/ChatGPT | ✓ Free | $20/month |
| Perplexity | ✓ Free | $20/month |
| MailerLite | ✓ Free (1k subs) | $10/month |
| Carrd | ✓ Free (1 site) | $19/year |
| Gumroad | ✓ Free (% fee) | $10/month |
| Canva | ✓ Free | $13/month |
| Opus Clip | ✓ Free (limited) | $13/month |

**Total at full paid stack: ~$76/month**  
**Total free tier: $0** (with percentage fees on sales)

For most users at this level: start free, upgrade individual tools as they become bottlenecks.

---

🔗 **https://autonomax-revenue-ops-71658389068.us-central1.run.app**

*AutonomaX Golden Delivery | Pro Edition*
