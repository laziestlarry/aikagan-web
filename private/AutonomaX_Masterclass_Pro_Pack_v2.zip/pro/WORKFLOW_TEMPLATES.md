# ⚡ Workflow Templates
### 6 Automation Workflows with Tool Mappings

Each workflow replaces a manual, repetitive task with an automated or semi-automated process. Start with Workflow 1. Add others as you scale.

---

## Workflow 1: Lead Magnet → Email Nurture → Offer
**Replaces:** Manually following up with every new subscriber  
**Tools:** Carrd → MailerLite → Gumroad  
**Setup time:** 3–4 hours (one time)

```
TRIGGER: Visitor fills opt-in form on landing page
     ↓
STEP 1: MailerLite automatically adds to "New Subscribers" list
     ↓
STEP 2: Email 1 sends immediately — delivers free lead magnet + welcome
     ↓
STEP 3: Email 2 sends after 24 hours — case study / insight
     ↓
STEP 4: Email 3 sends after 48 hours — what's inside the paid offer
     ↓
STEP 5: Email 4 sends after 72 hours — objection handling
     ↓
STEP 6: Email 5 sends after 96 hours — offer + link
     ↓
IF PURCHASE: MailerLite tag "Buyer" added (via Gumroad webhook or manual)
     ↓
IF NO PURCHASE: Move to weekly newsletter list (keep warm)
```

**Result:** Every new subscriber gets a consistent 5-day sales experience — without you doing anything after setup.

---

## Workflow 2: Purchase → Delivery → Upsell
**Replaces:** Manually sending products and following up after purchases  
**Tools:** Gumroad → Email (or MailerLite automation)  
**Setup time:** 1–2 hours

```
TRIGGER: Customer completes purchase on Gumroad
     ↓
STEP 1: Gumroad auto-delivers product (file or link) immediately
     ↓
STEP 2: Gumroad sends receipt email (customize this — add a personal note)
     ↓
STEP 3: 24 hours later — follow-up email:
     "How are you finding it? The #1 thing people use first is [X]."
     ↓
STEP 4: 48 hours later — upsell email:
     "Ready for the next level? The [Pro / Commander] Pack includes [X, Y, Z]: [LINK]"
     ↓
STEP 5: 7 days later — testimonial request:
     "Quick question — what's been most useful so far? I'd love a sentence for the sales page."
```

**Customize Gumroad's receipt email:**
Settings → Products → [Your Product] → Emails → Customize "Purchase Receipt" and "Delivery Email"

---

## Workflow 3: Social Post → DM Sequence
**Replaces:** Random, inconsistent outreach  
**Tools:** Native social platform + Claude for message drafts  
**Setup time:** 30 min template creation, then 15 min/day execution

```
TRIGGER: Someone comments on or likes your problem/insight post
     ↓
STEP 1: Check profile — do they match your target buyer? (30-second check)
     ↓
STEP 2 (if yes): Send Message Type 1 within 2 hours of engagement
     "Hey [Name] — your [comment/reaction] caught my attention.
     Quick question: [RELEVANT QUESTION]?"
     ↓
STEP 3 (if they reply): Continue conversation naturally
     → If interested: send offer
     → If not yet: add to follow-up list
     ↓
STEP 4 (follow-up if no reply after 3 days):
     "Circling back — still happy to help with [TOPIC] if timing works."
     ↓
STEP 5 (no reply after follow-up): Move on. Don't send a third time.
```

---

## Workflow 4: Weekly Content System
**Replaces:** Daily decision-making about what to post  
**Tools:** Claude (writing) + Buffer or native scheduler  
**Setup time:** 2 hours/week (batched)

```
EVERY SUNDAY (or Monday morning):
     ↓
STEP 1: List 3 buyer problems or questions from this week's conversations
     ↓
STEP 2: Use Claude to turn each into a post (3 posts)
     Prompt: "Turn this insight into a [LinkedIn/Twitter/Reddit] post 
     that teaches [LESSON] to [AUDIENCE]. 150 words max. No hashtags."
     ↓
STEP 3: Review, edit to sound like you
     ↓
STEP 4: Schedule all 3 posts using Buffer (free) or native scheduler
     → Monday, Wednesday, Friday
     ↓
STEP 5: Each post ends with a soft CTA: "Full [RESOURCE] in my bio/link."
     ↓
STEP 6: Monday-Friday: 15 min/day on genuine comment replies only
```

**The math:** 2 hours/week produces 3 pieces of content + daily engagement in 15 min.

---

## Workflow 5: Testimonial → Social Proof System
**Replaces:** Scrambling for proof when a potential buyer asks for it  
**Tools:** Gmail/email + Notion or Google Doc  
**Setup time:** 1 hour to create the system

```
TRIGGER: Customer responds positively to your 7-day follow-up email
     ↓
STEP 1: Reply: "This is great to hear. Could I use that as a testimonial?
         Even just that sentence — it helps others know this works."
     ↓
STEP 2 (if yes): Copy their words into your Proof Document
         Format: "[QUOTE]" — [First Name], [Role/Context], [Month Year]
     ↓
STEP 3: Add to landing page Proof block (update Carrd page)
     ↓
STEP 4: Create 1 social post featuring the testimonial:
         "[QUOTE]
          This is what [OFFER NAME] produces.
          Available here: [LINK]"
     ↓
STEP 5: Save full conversation to Proof Document (for reference)
```

**Goal:** 3 testimonials by end of Month 1. 10 by end of Month 3.

---

## Workflow 6: Weekly Revenue Review
**Replaces:** Flying blind without knowing what's actually working  
**Tools:** AutonomaX System + simple tracking spreadsheet  
**Setup time:** 30 min to create the spreadsheet, then 20 min/week

```
EVERY FRIDAY:
     ↓
STEP 1: Log weekly metrics in spreadsheet:
     → New opt-ins | New sales | Revenue | Top traffic source | Messages sent
     ↓
STEP 2: Open AutonomaX system — run weekly analysis
     https://autonomax-revenue-ops-71658389068.us-central1.run.app
     ↓
STEP 3: Answer 3 questions:
     → What produced the most revenue this week?
     → What did I spend time on that produced nothing?
     → What's one thing to do more of next week?
     ↓
STEP 4: Set 3 specific goals for next week (tasks, not outcomes)
     ↓
STEP 5: Archive this week's data + start fresh
```

---

## Workflow Priority Order

```
Priority 1 (Week 1): Workflow 2 — Purchase delivery + upsell
Priority 2 (Week 2): Workflow 1 — Lead magnet + email nurture
Priority 3 (Week 3): Workflow 4 — Weekly content system
Priority 4 (Week 4+): Workflows 3, 5, 6 — as activity increases
```

---

🔗 **https://autonomax-revenue-ops-71658389068.us-central1.run.app**

*AutonomaX Golden Delivery | Pro Edition*
