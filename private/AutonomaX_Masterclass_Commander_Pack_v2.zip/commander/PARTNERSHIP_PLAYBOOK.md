# 🤝 Partnership Playbook
### Collaboration Frameworks That Multiply Your Reach

---

## Why Partnerships Beat Ads (Usually)

A paid ad reaches cold strangers. A partnership reaches warm audiences who already trust the person introducing you.

Partnership economics at this level:
- Cost: time (not money)
- Reach: your partner's entire audience
- Trust transfer: their credibility extends to you
- Revenue share: typically 30–50% commission, or reciprocal promotion

**The math:** A partner with 1,000 engaged followers who sends one email about your $79 product, converting at 2%, generates $1,580 — at zero ad spend.

---

## Partnership Type 1: Content Swap
**Effort:** Low  
**Best for:** Early-stage (under 500 subscribers)  
**Structure:** You write content for their audience; they write for yours. No money changes hands.

**How to propose:**
```
"Hey [NAME] — I've been following your content on [TOPIC].

I think our audiences overlap in a useful way — you serve [THEIR AUDIENCE] 
and I serve [YOUR AUDIENCE], and both would benefit from [OVERLAP].

I'd love to do a simple content swap:
→ I write a [post / thread / email] for your audience about [TOPIC]
→ You do the same for mine

No pitch, just value. Interested?"
```

**Output:** Each partner gets a high-quality piece of content for their audience. No revenue split needed.

---

## Partnership Type 2: Affiliate/Commission Partnership
**Effort:** Medium  
**Best for:** When your product is proven (5+ buyers, some testimonials)  
**Structure:** Partner promotes your offer; you pay them 30–50% commission on sales.

**Commission rates by product type:**
| Product Price | Standard Commission | Premium Partner Commission |
|---|---|---|
| $29 | 40% ($11.60) | 50% ($14.50) |
| $79 | 35% ($27.65) | 40% ($31.60) |
| $149 | 30% ($44.70) | 40% ($59.60) |

**How to set up affiliates on Gumroad:**
Settings → Affiliates → Add Affiliate → Set commission rate → Share affiliate link

**How to recruit affiliates:**
```
"Hey [NAME] — I know your audience includes [TYPE OF PERSON].

I've built a [PRODUCT NAME] that [SPECIFIC RESULT] — 
it's been used by [X] people and gets [OUTCOME].

I'd love to offer you a 40% commission if you ever want to share it with your audience.
No obligation, no quota, no scripts. Just an open offer.

Here's a quick look at what it includes: [LINK]

Interested?"
```

---

## Partnership Type 3: Co-Creation
**Effort:** High  
**Best for:** When you want to create something bigger than either of you could alone  
**Structure:** You and a partner create a joint product, split revenue 50/50.

**Co-creation opportunity matrix:**

| Your Strength | Partner's Strength | What You Build Together |
|---|---|---|
| System/framework | Audience/following | Their brand + your system |
| Content/writing | Technical skills | Implementation guides |
| Your niche depth | Complementary niche | Cross-niche bundle |
| Small audience | Large audience | Co-branded launch |

**Co-creation agreement (informal minimum):**
1. Who contributes what (time, IP, content)
2. Who handles which customer service questions
3. Revenue split and payment timing
4. What happens if one person wants to stop

Put it in writing — even a Google Doc shared between both parties.

---

## Partnership Type 4: Bundle Partnership
**Effort:** Low  
**Best for:** Reaching new buyers quickly  
**Structure:** You contribute your product to a multi-creator bundle; buyers get many products for a single price.

**How it works:**
- An organizer creates a bundle (e.g., "AI Business Bundle — 15 products for $47")
- Each contributor adds their product (usually Starter-tier)
- Organizer promotes to their audience
- Each contributor promotes to theirs
- Everyone benefits from cross-audience exposure

**Where to find bundle opportunities:**
- Look for "bundle" opportunities posted in niche Facebook groups and communities
- Ask creators in your niche if they've organized or participated in bundles
- Organize your own: recruit 5–8 complementary creators, set a price, everyone promotes

---

## Partnership Type 5: Podcast / YouTube Feature
**Effort:** Medium  
**Best for:** Long-term audience building, authority positioning  
**Structure:** You appear on someone else's podcast or channel as an expert guest.

**Guest pitch template:**
```
Subject: Guest pitch — [TOPIC] for [PODCAST/CHANNEL NAME]

Hi [HOST NAME],

I've been listening to / watching [PODCAST/CHANNEL] for [TIME].
Your [SPECIFIC EPISODE] on [TOPIC] was particularly valuable because [REASON].

I'm [YOUR NAME] — I [ONE SENTENCE ON WHAT YOU DO].

I think your audience would benefit from an episode on [SPECIFIC TOPIC], 
specifically [THE ANGLE THAT HASN'T BEEN COVERED].

Some things I could cover:
• [Point 1]
• [Point 2]  
• [Point 3]

I'll bring the content; you bring the audience. 
Would this be a fit for an upcoming episode?"
```

**Goal:** 2–4 podcast/video appearances per month = consistent warm traffic at zero cost.

---

## Partner Qualification Framework

Not every potential partner is worth your time. Before pursuing:

**Green light (pursue):**
- [ ] Their audience matches your target buyer
- [ ] Their content quality is similar to or higher than yours
- [ ] They're genuinely engaged with their audience (not just broadcasting)
- [ ] They have a track record of honoring partnerships

**Yellow light (proceed carefully):**
- [ ] Large audience but low engagement
- [ ] New to partnerships, unclear expectations
- [ ] Very different niche but some overlap

**Red light (avoid):**
- [ ] They've burned other partners (ask around)
- [ ] Their audience is low-quality or disengaged
- [ ] They want exclusivity without justification
- [ ] No track record of following through

---

## Partnership Outreach Calendar

Execute this weekly to build your partnership funnel:

| Day | Action |
|---|---|
| Monday | Identify 3 new potential partners (research phase) |
| Tuesday | Send 2 partnership messages (content swap or affiliate) |
| Wednesday | Follow up on previous week's outreach |
| Thursday | Engage genuinely with potential partners' content |
| Friday | Review active partnerships — are they progressing? |

**Monthly targets:**
- Month 1: 3 content swap partnerships live
- Month 2: 2 affiliate partners sending traffic
- Month 3: 1 co-creation or bundle collaboration launched

---

🔗 **https://autonomax-revenue-ops-71658389068.us-central1.run.app**

*AutonomaX Golden Delivery | Commander Edition*
