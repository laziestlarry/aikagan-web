# 📊 KPI Dashboard
### What to Measure, When, and How to Interpret It

---

## The Metrics That Actually Matter

Most people track vanity metrics (followers, likes, impressions). These feel good and tell you almost nothing about your business health.

Track these instead:

---

## Tier 1: Revenue Metrics (Track Weekly)

| Metric | Formula | Healthy Target |
|---|---|---|
| **Weekly Revenue** | Sum of all payments received | Growing week-over-week |
| **Monthly Recurring Revenue (MRR)** | Continuity members × price | ≥ 20% of total revenue |
| **Customer Lifetime Value (LTV)** | Total revenue ÷ total customers | ≥ 3× entry price |
| **Revenue Per Subscriber** | Monthly revenue ÷ email list size | ≥ $1/subscriber/month |

**LTV target explanation:**
If your entry offer is $29, your target LTV is $87+ (meaning: average customer spends $87 across all tiers). At Pro tier ($79 entry), target LTV is $237+.

---

## Tier 2: Funnel Metrics (Track Weekly)

| Metric | Formula | Healthy Target |
|---|---|---|
| **Landing page conversion rate** | Purchases ÷ unique visitors | ≥ 2% |
| **Email opt-in rate** | Opt-ins ÷ landing page visitors | ≥ 20% |
| **Email open rate** | Opens ÷ delivered | ≥ 30% |
| **Email click-to-open rate (CTOR)** | Clicks ÷ opens | ≥ 15% |
| **Sales email conversion rate** | Purchases ÷ sales email recipients | ≥ 1.5% |
| **Upsell rate (Starter → Pro)** | Pro purchases from Starter buyers ÷ Starter buyers | ≥ 15% |
| **Upsell rate (Pro → Commander)** | Commander from Pro buyers ÷ Pro buyers | ≥ 20% |

---

## Tier 3: Acquisition Metrics (Track Weekly)

| Metric | Formula | Healthy Target |
|---|---|---|
| **New subscribers** | New email opt-ins this week | Growing consistently |
| **Customer Acquisition Cost (CAC)** | Marketing spend ÷ new customers | < 30% of entry price |
| **Organic vs. paid traffic ratio** | Organic visitors ÷ total visitors | ≥ 70% organic |
| **Top traffic source** | Which source drove most buyers? | Track but no fixed target |

---

## Tier 4: Retention Metrics (Track Monthly)

| Metric | Formula | Healthy Target |
|---|---|---|
| **Continuity churn rate** | Members who cancel ÷ total members | ≤ 5%/month |
| **Customer return rate** | Customers who bought a 2nd product ÷ total customers | ≥ 25% |
| **Net Promoter Score (NPS proxy)** | % who refer someone else | ≥ 20% |

---

## Your Weekly Dashboard Template

Fill this in every Friday:

```
WEEK OF: ________________

REVENUE
├── New sales (count): _______
├── New revenue: $_______
├── MRR change: +/- $_______
└── LTV average (all customers): $_______

FUNNEL
├── Landing page visitors: _______
├── Opt-in rate: _______%
├── Email open rate (avg): _______%
└── Sales email conversion: _______%

ACQUISITION
├── New email subscribers: _______
├── Top source this week: _______
└── DMs/outreach sent: _______

RETENTION
├── New continuity members: _______
├── Cancellations: _______
└── Upsells this week: _______

THIS WEEK'S WIN: _______________________
THIS WEEK'S MISS: ______________________
NEXT WEEK'S PRIORITY: __________________
```

---

## How to Interpret the Data

### Scenario 1: Traffic is high, sales are low
**Diagnosis:** Funnel conversion problem (landing page or offer clarity)  
**Action:** Run a headline A/B test. Check if the price is visible and the CTA is clear.

### Scenario 2: Sales are consistent but LTV is low
**Diagnosis:** Upsell path is weak or absent  
**Action:** Strengthen upsell email sequence. Add upsell mention to thank-you page.

### Scenario 3: Email list is growing but sales aren't
**Diagnosis:** Email sequence isn't converting  
**Action:** Check email open rates (subject line issue?) and CTOR (copy issue?). Rewrite weakest email.

### Scenario 4: Good sales but high churn on continuity
**Diagnosis:** Product-market fit issue on the membership  
**Action:** Survey churned members ("What made you decide to cancel?"). Adjust based on pattern.

### Scenario 5: Everything looks healthy but revenue plateaued
**Diagnosis:** Traffic ceiling — you've tapped your current audience  
**Action:** New traffic source (per `TRAFFIC_PLAYBOOK.md`) or partnership campaign (per `PARTNERSHIP_PLAYBOOK.md`).

---

## Red Flags (Act Immediately)

- Email open rate drops below 20% in a single week → check deliverability, spam score
- Payment failures spike → check Gumroad/Stripe for issues, email affected customers
- Refund requests cluster around a single product → something in delivery is broken
- Unsubscribes spike after a specific email → that email needs a complete rewrite

---

🔗 **https://autonomax-revenue-ops-71658389068.us-central1.run.app**

*AutonomaX Golden Delivery | Commander Edition*
