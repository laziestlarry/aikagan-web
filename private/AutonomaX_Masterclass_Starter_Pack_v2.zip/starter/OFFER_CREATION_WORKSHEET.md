# 📋 Offer Creation Worksheet
### Build Your First Sellable Offer in 30 Minutes

Complete every field. Don't skip. Don't write "TBD." Your offer can't be sold if it only exists in your head.

---

## SECTION 1: Your Target Buyer (10 minutes)

**1.1 — Who is your buyer? (one specific type of person)**

> Example: "Freelance web designers who have 2–5 clients and want to get to 10"

Your answer: _______________________________________________

---

**1.2 — What is the #1 problem they have that you can solve?**

> Example: "They don't know how to find clients other than word-of-mouth"

Your answer: _______________________________________________

---

**1.3 — What have they already tried that didn't work?**

> Example: "Cold emailing, posting on Upwork, asking friends"

Your answer: _______________________________________________

---

**1.4 — What do they *actually* want (the emotional outcome, not the logical one)?**

> Example: "They want financial security and to stop worrying about next month's rent"

Your answer: _______________________________________________

---

**1.5 — Where do these people hang out online right now?**

List 2–3 specific places (subreddit names, Facebook group names, Discord servers, LinkedIn groups):

1. _______________________________________________
2. _______________________________________________
3. _______________________________________________

---

## SECTION 2: Your Offer (10 minutes)

**2.1 — What is the specific deliverable? (circle one)**

- [ ] PDF / Guide / Report
- [ ] Video walkthrough (Loom)
- [ ] Template pack (copy-paste files)
- [ ] 30-minute strategy call + action plan
- [ ] Mini-audit of their specific situation
- [ ] Checklist / SOP
- [ ] Other: _______________

---

**2.2 — What is the specific result the buyer gets?**

> Example: "A completed 3-email abandoned cart sequence ready to activate in their Klaviyo account"

Your answer: _______________________________________________

---

**2.3 — How long does it take them to see the result?**

> Example: "Within 24 hours of implementing"

Your answer: _______________________________________________

---

**2.4 — What is your price?**

> Recommended range for first sale: $29 – $97
> Rule: Price at the point where a "yes" feels easy but not free.

Your price: $___________

---

**2.5 — Write your One-Sentence Offer using this formula:**

> "I help [WHO] achieve [SPECIFIC RESULT] in [TIMEFRAME] without [PAIN]."

Your offer sentence: _______________________________________________

---

## SECTION 3: Delivery + Payment (5 minutes)

**3.1 — How will you take payment?**

- [ ] Stripe payment link (stripe.com)
- [ ] Gumroad product page (gumroad.com)
- [ ] PayPal invoice
- [ ] Ko-fi
- [ ] Other: _______________

Payment link (fill in once created): _______________________________________________

---

**3.2 — How will you deliver the product?**

- [ ] Gumroad/Lemon Squeezy auto-delivery
- [ ] Google Drive folder (share after payment)
- [ ] Notion page (share link after payment)
- [ ] Email with attachment
- [ ] Zoom/Google Meet link (for calls)

---

**3.3 — What do you already have ready to deliver right now?**

Be honest. List what exists:

_______________________________________________

**What do you need to create before your first sale?**

Time estimate: ___________ hours

---

## SECTION 4: Your Offer Name + Headline (5 minutes)

**4.1 — Give your offer a simple, clear name:**

> Examples: "Freelance Client Finder Checklist" | "3-Email Cart Recovery Setup" | "30-Min Revenue Audit"

Your offer name: _______________________________________________

---

**4.2 — Write a one-line description (for social posts / DMs / listing pages):**

> Example: "A step-by-step checklist to get your next 3 freelance clients in 2 weeks — no cold calls."

Your description: _______________________________________________

---

## SECTION 5: Offer Validation Check

Before sending your first message, confirm:

- [ ] I can name exactly who this is for
- [ ] I can describe the result in one specific sentence
- [ ] I have a way to take payment right now
- [ ] I can deliver this within 24–48 hours of purchase
- [ ] I know at least 5 specific people who fit this buyer profile

If all 5 are checked: **You're ready. Go to `FIRST_SALE_BLUEPRINT.md` Day 3.**

If any are unchecked: **Spend 15 more minutes on those sections first.**

---

## Your Completed Offer Summary (Fill This In Last)

```
OFFER NAME:        ________________________________
WHO IT'S FOR:      ________________________________
WHAT THEY GET:     ________________________________
THE RESULT:        ________________________________
TIMEFRAME:         ________________________________
PRICE:             $__________
PAYMENT LINK:      ________________________________
DELIVERY METHOD:   ________________________________
```

Pin this somewhere visible. This is your north star for the next 7 days.

---

🔗 Ready to connect your offer to the live system: **https://autonomax-revenue-ops-71658389068.us-central1.run.app**

*AutonomaX Golden Delivery | Starter Edition*
